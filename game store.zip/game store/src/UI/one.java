package UI;

import java.sql.Connection;
import java.util.Scanner;
import service.*;

public class one {
    public static void main(String[] args) throws Exception {
        Connection cot = JDBCutil.getConnection();
        Scanner scanner = new Scanner(System.in);
        int username=0;
        //Statement st = cot.createStatement();
       while (true){
           before be = new before();
           be.bef();
           int choice = scanner.nextInt();
           if (choice == 1) {
               System.out.println("请输入账号:");
               username = scanner.nextInt();
               System.out.println("请输入密码:");
               int pw = scanner.nextInt();
               createuser su = new createuser();
               su.create(cot,username,pw);
           }
           else if (choice == 3) {
               System.out.println("退出成功");
               break;
           }
           else if (choice == 2) {
               System.out.println("请输入账号:");
                username = scanner.nextInt();
               System.out.println("请输入密码:");
               int pw = scanner.nextInt();
               login lg = new login();
               lg.login(cot,username,pw);
               break;
           }
       }
       while (true){
           after af = new after();
           af.aft();
           int choice = scanner.nextInt();
           if (choice == 1) {
               look lk = new look();
               lk.look(cot,username);
           }
           else if (choice == 2) {
               topup tp = new topup();
               tp.recharge(cot,username);
           }
           else if (choice == 3) {
               prop pro = new prop();
               pro.show(cot);
               System.out.println("1.购买");
               System.out.println("2.退出");
               int choice1 = scanner.nextInt();
               if (choice1 == 1){
                   System.out.println("请输入你要购买道具的id号：");
                   int ID=scanner.nextInt();
                   System.out.println("请输入你要购买的数量：");
                   int num = scanner.nextInt();
                   add ad = new add();
                   ad.append(cot,ID,num);
                   System.out.println("已添加到购物车");
               }
           }
           else if (choice == 4) {
               cart ct = new cart();
               ct.shopping(cot);
               System.out.println("1.付款");
               System.out.println("2.清空购物车");
               System.out.println("3.退出");
               int choice1 = scanner.nextInt();
               if (choice1 == 1){
                   clear ce = new clear();
                   ce.buy(cot,1,username);
               }
               else if (choice1 == 2){
                   clear ce = new clear();
                   ce.buy(cot,2,username);
               }
           }
           else if (choice == 5) {
               break;
           }
       }
//        System.out.println("1.查询余额");
//        look lk = new look();
//        lk.look(cot,username);
//        System.out.println("2.充值");
//        topup tp = new topup();
//        tp.recharge(cot,username);
//        System.out.println("3.进入商城");
//        prop pro = new prop();
//        pro.show(cot);
//        System.out.println("请输入你要购买道具的id号：");
//        int ID=scanner.nextInt();
//        System.out.println("请输入你要购买的数量：");
//        int num = scanner.nextInt();
//        add ad = new add();
//        ad.append(cot,ID,num);
//        System.out.println("4.查看购物车");
//        cart ct = new cart();
//        ct.shopping(cot);
//        System.out.println("5.退出");
//        clear ce = new clear();
//        ce.buy(cot,1,username);
        cot.close();
    }
}
