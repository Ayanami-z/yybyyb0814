package UI;

public class after {
    public void aft() {
        System.out.println("1.查询余额");
        System.out.println("2.充值");
        System.out.println("3.进入商城");
        System.out.println("4.查看购物车");
        System.out.println("5.退出");
    }
}
