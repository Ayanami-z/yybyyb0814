package UI;

public class before {
    public void bef() {
        System.out.println("1.创建用户");
        System.out.println("2.登录");
        System.out.println("3.退出");
    }
}
