package Dao;

public class props {                //商城对象
    public int id;
    public String propname;
    public int price;

    public props() {
    }

    public props(int id, String propname, int price) {
        this.id = id;
        this.propname = propname;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPropname() {
        return propname;
    }

    public void setPropname(String propname) {
        this.propname = propname;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return  "序号：" + id +
                ", 道具名称：'" + propname + '\'' +
                ", 价格：" + price;
    }
}
