package Dao;

public class carts {            //购物车对象
    int id;
    String name;
    int num;
    int price;

    public carts() {
    }

    public carts(int id, String name, int num, int price) {
        this.id = id;
        this.name = name;
        this.num = num;
        this.price = price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getNum() {
        return num;
    }

    public void setNum(int num) {
        this.num = num;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    @Override
    public String toString() {
        return "订单号：" + id +
                ", 道具名称：'" + name + '\'' +
                ", 数量：" + num +
                ", 金额：" + price;
    }
}
