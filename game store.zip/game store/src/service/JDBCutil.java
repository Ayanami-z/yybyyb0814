package service;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

//返回Connection对象
public class JDBCutil {
    public static Connection getConnection() throws ClassNotFoundException, SQLException {
        Class.forName("com.mysql.jdbc.Driver");
        return DriverManager.
                getConnection
                        ("jdbc:mysql://localhost:3306/game store?serverTimezone=GMT%2B8&characterEncoding=utf8&useSSL=true","root","040617");
    }
}
