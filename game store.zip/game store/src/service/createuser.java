package service;

import java.sql.Connection;
import java.sql.PreparedStatement;

//创建用户
public class createuser {
    public  void create(Connection cot,int username,int pw) throws Exception{
        String sql="insert into users(id,username,pw) values (?,?,?)";
        PreparedStatement preparedStatement = cot.prepareStatement(sql);
        preparedStatement.setObject(1,null);
        preparedStatement.setObject(2,username);
        preparedStatement.setObject(3,pw);
        boolean b = preparedStatement.execute();
        if(!b){
            System.out.println("创建成功");
        }
        else {
            System.out.println("创建失败");
        }
        preparedStatement.close();
    }
}

