package service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import Dao.props;
//输出商城
public class prop {
    public void show(Connection cot) throws Exception{
        Statement st = cot.createStatement();
        ResultSet re=st.executeQuery("select * from prop");
        ArrayList<props> ue=new ArrayList<>();
        while (re.next()) {
            props p= new props();
            p.setId(re.getInt("id"));
            p.setPropname(re.getString("propname"));
            p.setPrice(re.getInt("price"));
            ue.add(p);
        }
        for (props p: ue) {
            System.out.println(p);
        }
        re.close();
        st.close();
    }
}
