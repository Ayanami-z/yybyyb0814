package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

//添加道具到购物车
public class add {
    public void append(Connection cot,int id,int num) throws Exception{
        String sql="select * from prop where id=?";
        PreparedStatement ps = cot.prepareStatement(sql);
        ps.setObject(1,id);
        ResultSet resultSet = ps.executeQuery();
        ResultSetMetaData metaData = resultSet.getMetaData();
        // System.out.println(metaData);
        int columnCount = metaData.getColumnCount();
        String name="";
        int price=0;
        while (resultSet.next()) {
            int ID = resultSet.getInt("id");
            name = resultSet.getString("propname");
            price = resultSet.getInt("price");
        }
        String sql2="insert into cart(id,propname,num,price) values(?,?,?,?)";
        PreparedStatement ps2 = cot.prepareStatement(sql2);
        ps2.setObject(1,null);
        ps2.setString(2,name);
        ps2.setInt(3,num);
        price=price*num;
        ps2.setInt(4,price);
        ps2.executeUpdate();
        ps.close();
        ps2.close();
    }
}
