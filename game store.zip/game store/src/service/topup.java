package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Scanner;

//充值功能
public class topup {
    public void recharge(Connection cot,int username) throws Exception {
        Scanner sc = new Scanner(System.in);
        System.out.println("请输入您想要充值的金额(1$=10金币)：");
        int m = sc.nextInt();
        int money = m*10;
        //System.out.println(m+"    "+money);
        String sql = "update users set money=money+? where username=?";
        PreparedStatement ps = cot.prepareStatement(sql);
        ps.setInt(1,money);
        ps.setInt(2,username);
        ps.executeUpdate();
//        System.out.println("充值成功");
//        int resultSet = ps.executeUpdate(sql);
//        Statement st = cot.createStatement();
//        int i=st.executeUpdate("update users set money=money where username=username");
//        if(i>0){
//            System.out.println("充值成功");
//        }
//        else {
//            System.out.println("充值失败");
//        }
//        st.close();
    }
}
