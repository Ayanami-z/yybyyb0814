package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

//查看余额
public class look {
    public void look(Connection cot,int username) throws Exception {
        String sql = "select money from users where username=?";
        PreparedStatement ps = cot.prepareStatement(sql);
        ps.setInt(1,username);
        ResultSet rs = ps.executeQuery();
        while (rs.next()) {
            int money = rs.getInt("money");
            System.out.println("当前金币："+money);
        }
        ps.close();
    }
}
