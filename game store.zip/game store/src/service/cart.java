package service;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import Dao.carts;

//输出购物车
public class cart {
    public void shopping(Connection cot) throws Exception {
        Statement st = cot.createStatement();
        ResultSet re=st.executeQuery("select * from cart");
        ArrayList<carts> ct=new ArrayList<>();
        while (re.next()) {
            carts c= new carts();
            c.setId(re.getInt("id"));
            c.setName(re.getString("propname"));
            c.setNum(re.getInt("num"));
            c.setPrice(re.getInt("price"));
            ct.add(c);
        }
        for (carts s: ct) {
            System.out.println(s);
        }
        re.close();
        st.close();
    }
}
