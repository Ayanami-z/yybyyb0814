package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;

//登录功能
public class login {
    public void login(Connection cot, int username, int pw) throws Exception {
        String sql = "select * from users where username=? ";
        PreparedStatement ps = cot.prepareStatement(sql);
        ps.setObject(1,username);
        ResultSet resultSet = ps.executeQuery();
        ResultSetMetaData metaData = resultSet.getMetaData();
       // System.out.println(metaData);
        int columnCount = metaData.getColumnCount();
        while (resultSet.next()) {
            int u = resultSet.getInt("username");
            int p = resultSet.getInt("pw");
            if(username==u&&pw==p){
                System.out.println("登录成功");
            }
            else {
                System.out.println("登录失败，请重试");
                System.exit(0);
            }
        }
//        boolean b = ps.execute();
//        if(!b){
//            System.out.println("登录成功");
//        }
//        else {
//            System.out.println("登录失败");
//        }
        ps.close();
    }
}
