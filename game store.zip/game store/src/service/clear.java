package service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

//清空购物车
public class clear {
    public void buy(Connection cot,int choice,int username) throws Exception {
        int price=0;
        int money=0;
        String sql="select price from cart";
        PreparedStatement pst=cot.prepareStatement(sql);
        ResultSet rs=pst.executeQuery();
        while (rs.next()){
            int p=rs.getInt("price");
            price=price+p;
        }
        String sql2 = "select money from users where username=?";
        PreparedStatement ps = cot.prepareStatement(sql2);
        ps.setInt(1,username);
        ResultSet re = ps.executeQuery();
        while (re.next()) {
            money = re.getInt("money");
        }
        if (choice == 1) {
            if (money >= price) {
                String sql3 = "truncate table cart";
                PreparedStatement p = cot.prepareStatement(sql3);
                p.executeUpdate();
                String sql4 = "update users set money=money-? where username=?";
                PreparedStatement p2 = cot.prepareStatement(sql4);
                p2.setInt(1,price);
                p2.setInt(2,username);
                p2.executeUpdate();
                System.out.println("购买成功");
            }
            else{
                System.out.println("余额不足");
            }
        }
        if (choice == 2) {
            String sql3 = "truncate table cart";
            PreparedStatement p = cot.prepareStatement(sql3);
            p.executeUpdate();
            System.out.println("清空成功");
        }
    }
}
